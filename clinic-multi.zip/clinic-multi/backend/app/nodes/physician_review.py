from backend.app.state import MedicalState


def physician_review_node(state: MedicalState) -> MedicalState:
    """
    Human-in-the-Loop step.

    In the API/frontend, the workflow stops here until the doctor provides:
    - treatment
    - notes
    - conduct to follow
    """

    if state.get("physician_treatment"):
        return {
            "session_status": "physician_reviewed",
        }

    return {
        "session_status": "awaiting_physician_review",
    }