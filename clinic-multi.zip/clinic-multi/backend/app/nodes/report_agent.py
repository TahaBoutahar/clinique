from backend.app.state import MedicalState


def report_agent_node(state: MedicalState) -> MedicalState:
    """
    Report Agent:
    Generates the final structured report after physician review.
    """

    final_report = f"""
RAPPORT FINAL STRUCTURÉ

1. Cas initial patient
{state.get("patient_initial_case", "Non renseigné")}

2. Synthèse clinique préliminaire
{state.get("diagnostic_summary", "Non disponible")}

3. Recommandation intermédiaire
{state.get("interim_care", "Non disponible")}

4. Revue du médecin traitant
Traitement ou conduite à tenir :
{state.get("physician_treatment", "Non renseigné")}

Notes du médecin :
{state.get("physician_notes", "Aucune note ajoutée")}

5. Mention obligatoire
Ce système ne remplace pas une consultation médicale.
""".strip()

    return {
        "final_report": final_report,
        "session_status": "completed",
        "next": "FINISH",
    }