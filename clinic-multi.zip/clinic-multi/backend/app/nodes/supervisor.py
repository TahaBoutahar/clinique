from backend.app.state import MedicalState


def supervisor_node(state: MedicalState) -> MedicalState:
    """
    The supervisor decides the next step of the workflow.
    """

    if state.get("final_report"):
        return {"next": "FINISH"}

    if state.get("physician_treatment"):
        return {"next": "report_agent"}

    if state.get("session_status") == "awaiting_patient_answer":
        return {"next": "FINISH"}

    if state.get("session_status") == "awaiting_physician_review":
        return {"next": "FINISH"}

    if state.get("diagnostic_summary") and state.get("interim_care"):
        return {"next": "physician_review"}

    return {"next": "diagnostic_agent"}


def route_supervisor(state: MedicalState) -> str:
    """
    Used by LangGraph conditional edges.
    """

    return state.get("next", "FINISH")