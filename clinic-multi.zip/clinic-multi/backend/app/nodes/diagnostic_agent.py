from backend.app.state import MedicalState
from backend.app.tools.patient_tools import get_next_patient_question
from backend.app.tools.care_tools import recommend_interim_care, detect_red_flags
from backend.app.tools.mcp_client import call_mcp_interim_care_sync


def diagnostic_agent_node(state: MedicalState) -> MedicalState:
    """
    Diagnostic Agent:
    - asks exactly 5 patient questions
    - after 5 answers, produces a preliminary clinical synthesis
    - generates an intermediate recommendation using MCP
    """

    patient_initial_case = state.get("patient_initial_case", "")
    patient_answers = state.get("patient_answers", [])
    questions_asked = state.get("questions_asked", [])

    question_count = len(patient_answers)

    if question_count < 5:
        next_question = get_next_patient_question(
            question_count=question_count,
            patient_initial_case=patient_initial_case,
        )

        updated_questions = questions_asked.copy()

        if len(updated_questions) <= question_count:
            updated_questions.append(next_question)

        return {
            "question_count": question_count,
            "questions_asked": updated_questions,
            "current_question": next_question,
            "session_status": "awaiting_patient_answer",
        }

    try:
        mcp_result = call_mcp_interim_care_sync(
            patient_initial_case=patient_initial_case,
            patient_answers=patient_answers,
        )

        red_flags_detected = bool(mcp_result.get("red_flags_detected", False))
        interim_care = (
            mcp_result.get("interim_care", "")
            + " "
            + mcp_result.get("safety_notice", "Ce système ne remplace pas une consultation médicale.")
        )

    except Exception as error:
        # Safe fallback if MCP server fails.
        print(f"MCP error, using local fallback: {error}")

        red_flags_detected = detect_red_flags(patient_answers)
        interim_care = recommend_interim_care(patient_answers)

    answers_text = "\n".join(
        [
            f"Question {index + 1}: {questions_asked[index] if index < len(questions_asked) else 'Question non disponible'}\n"
            f"Réponse: {answer}"
            for index, answer in enumerate(patient_answers)
        ]
    )

    diagnostic_summary = f"""
Synthèse clinique préliminaire

Cas initial patient :
{patient_initial_case}

Informations recueillies :
{answers_text}

Orientation clinique préliminaire :
Les informations recueillies permettent de formuler une orientation clinique préliminaire.
Cette synthèse ne constitue pas un diagnostic définitif.

Signes d’alerte détectés :
{"Oui" if red_flags_detected else "Non"}

Outil utilisé :
MCP clinical_interim_care_tool
""".strip()

    return {
        "question_count": question_count,
        "diagnostic_summary": diagnostic_summary,
        "interim_care": interim_care,
        "red_flags_detected": red_flags_detected,
        "session_status": "diagnostic_complete",
    }