from typing import Annotated, Literal
from typing_extensions import TypedDict
from langgraph.graph.message import add_messages


class MedicalState(TypedDict, total=False):
    messages: Annotated[list, add_messages]

    next: Literal[
        "diagnostic_agent",
        "physician_review",
        "report_agent",
        "FINISH",
    ]

    patient_initial_case: str

    question_count: int
    current_question: str
    questions_asked: list[str]
    patient_answers: list[str]

    diagnostic_summary: str
    interim_care: str

    physician_treatment: str
    physician_notes: str

    final_report: str
    red_flags_detected: bool
    session_status: str