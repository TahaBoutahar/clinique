from typing import Any, Dict, Optional
from uuid import uuid4

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from backend.app.graph import graph
from backend.app.state import MedicalState


app = FastAPI(
    title="Medical Multi-Agent Clinical Orientation API",
    description="Academic multi-agent project using LangGraph, FastAPI and Human-in-the-Loop.",
    version="1.0.0",
)

# For frontend later
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Temporary in-memory storage.
# Later we can replace this with SQLite/PostgreSQL if needed.
SESSIONS: Dict[str, MedicalState] = {}


class StartSessionRequest(BaseModel):
    patient_initial_case: str


class ResumeConsultationRequest(BaseModel):
    thread_id: str
    patient_answer: Optional[str] = None
    physician_treatment: Optional[str] = None
    physician_notes: Optional[str] = None


class ApiResponse(BaseModel):
    thread_id: str
    status: str
    state: Dict[str, Any]


def create_initial_state(patient_initial_case: str) -> MedicalState:
    return {
        "messages": [],
        "next": "diagnostic_agent",
        "question_count": 0,
        "patient_initial_case": patient_initial_case,
        "patient_answers": [],
        "questions_asked": [],
        "interim_care": "",
        "diagnostic_summary": "",
        "physician_treatment": "",
        "physician_notes": "",
        "final_report": "",
        "red_flags_detected": False,
        "session_status": "started",
    }


@app.get("/")
def root():
    return {
        "message": "Medical Multi-Agent API is running.",
        "warning": "Ce système ne remplace pas une consultation médicale.",
    }


@app.post("/sessions/start", response_model=ApiResponse)
def start_session(payload: StartSessionRequest):
    """
    Starts a new consultation session.
    The graph should ask the first patient question.
    """

    thread_id = str(uuid4())

    initial_state = create_initial_state(payload.patient_initial_case)
    updated_state = graph.invoke(initial_state)

    SESSIONS[thread_id] = updated_state

    return {
        "thread_id": thread_id,
        "status": updated_state.get("session_status", "unknown"),
        "state": updated_state,
    }


@app.post("/consultation/start", response_model=ApiResponse)
def start_consultation(payload: StartSessionRequest):
    """
    Alias endpoint required by the project specification.
    """

    return start_session(payload)


@app.post("/consultation/resume", response_model=ApiResponse)
def resume_consultation(payload: ResumeConsultationRequest):
    """
    Resumes the workflow.

    This endpoint handles two moments:
    1. Patient answering one of the 5 questions.
    2. Physician submitting review/treatment.
    """

    thread_id = payload.thread_id

    if thread_id not in SESSIONS:
        raise HTTPException(status_code=404, detail="Session not found")

    current_state = SESSIONS[thread_id]
    session_status = current_state.get("session_status")

    # Case 1: patient answer
    if session_status == "awaiting_patient_answer":
        if not payload.patient_answer:
            raise HTTPException(
                status_code=400,
                detail="patient_answer is required at this step",
            )

        patient_answers = current_state.get("patient_answers", []).copy()
        patient_answers.append(payload.patient_answer)

        current_state["patient_answers"] = patient_answers
        current_state["question_count"] = len(patient_answers)
        current_state["session_status"] = "patient_answer_received"

        updated_state = graph.invoke(current_state)
        SESSIONS[thread_id] = updated_state

        return {
            "thread_id": thread_id,
            "status": updated_state.get("session_status", "unknown"),
            "state": updated_state,
        }

    # Case 2: physician review
    if session_status == "awaiting_physician_review":
        if not payload.physician_treatment:
            raise HTTPException(
                status_code=400,
                detail="physician_treatment is required at this step",
            )

        current_state["physician_treatment"] = payload.physician_treatment
        current_state["physician_notes"] = payload.physician_notes or ""
        current_state["session_status"] = "physician_review_submitted"

        updated_state = graph.invoke(current_state)
        SESSIONS[thread_id] = updated_state

        return {
            "thread_id": thread_id,
            "status": updated_state.get("session_status", "unknown"),
            "state": updated_state,
        }

    # Already completed
    if session_status == "completed":
        return {
            "thread_id": thread_id,
            "status": "completed",
            "state": current_state,
        }

    raise HTTPException(
        status_code=400,
        detail=f"Cannot resume consultation from status: {session_status}",
    )


@app.get("/consultation/{thread_id}", response_model=ApiResponse)
def get_consultation(thread_id: str):
    """
    Gets the current state of a consultation.
    """

    if thread_id not in SESSIONS:
        raise HTTPException(status_code=404, detail="Session not found")

    state = SESSIONS[thread_id]

    return {
        "thread_id": thread_id,
        "status": state.get("session_status", "unknown"),
        "state": state,
    }


@app.get("/consultation/{thread_id}/report")
def get_report(thread_id: str):
    """
    Gets the final report.
    """

    if thread_id not in SESSIONS:
        raise HTTPException(status_code=404, detail="Session not found")

    state = SESSIONS[thread_id]

    if not state.get("final_report"):
        raise HTTPException(
            status_code=400,
            detail="Final report is not ready yet",
        )

    return {
        "thread_id": thread_id,
        "status": state.get("session_status", "unknown"),
        "final_report": state.get("final_report"),
    }