import asyncio
import json
from typing import Any, Dict, List

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


async def call_mcp_interim_care(
    patient_initial_case: str,
    patient_answers: List[str],
) -> Dict[str, Any]:
    """
    Calls the local MCP server through stdio.
    """

    server_params = StdioServerParameters(
        command="uv",
        args=["run", "python", "mcp_server/server.py"],
    )

    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()

            result = await session.call_tool(
                "clinical_interim_care_tool",
                arguments={
                    "patient_initial_case": patient_initial_case,
                    "patient_answers": patient_answers,
                },
            )

            if not result.content:
                raise RuntimeError("MCP tool returned empty content")

            text_content = result.content[0].text
            return json.loads(text_content)


def call_mcp_interim_care_sync(
    patient_initial_case: str,
    patient_answers: List[str],
) -> Dict[str, Any]:
    """
    Synchronous wrapper used by LangGraph nodes.
    """

    return asyncio.run(
        call_mcp_interim_care(
            patient_initial_case=patient_initial_case,
            patient_answers=patient_answers,
        )
    )