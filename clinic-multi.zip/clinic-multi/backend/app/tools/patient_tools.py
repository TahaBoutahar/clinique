def get_next_patient_question(question_count: int, patient_initial_case: str) -> str:
    """
    Returns the next patient question.
    The project requires exactly 5 patient questions.
    """

    questions = [
        "Depuis quand avez-vous ces symptômes ?",
        "Avez-vous de la fièvre, des douleurs, une fatigue importante ou d’autres signes associés ?",
        "Avez-vous des antécédents médicaux importants ou prenez-vous un traitement actuellement ?",
        "Les symptômes s’aggravent-ils, s’améliorent-ils ou restent-ils stables ?",
        "Avez-vous des signes inquiétants comme une difficulté à respirer, une douleur intense, une confusion ou une aggravation rapide ?",
    ]

    if question_count < len(questions):
        return questions[question_count]

    return ""