def detect_red_flags(patient_answers: list[str]) -> bool:
    red_flag_keywords = [
        "difficulté à respirer",
        "respirer",
        "douleur intense",
        "confusion",
        "perte de connaissance",
        "sang",
        "aggravation rapide",
        "urgence",
    ]

    combined_answers = " ".join(patient_answers).lower()

    return any(keyword in combined_answers for keyword in red_flag_keywords)


def recommend_interim_care(patient_answers: list[str]) -> str:
    """
    Generates a cautious intermediate recommendation.
    This is not a diagnosis.
    """

    red_flags = detect_red_flags(patient_answers)

    if red_flags:
        return (
            "Recommandation intermédiaire : présence possible de signes d’alerte. "
            "Une consultation médicale rapide ou une orientation vers un service d’urgence est recommandée "
            "en cas d’aggravation, de difficulté respiratoire, de douleur intense ou de trouble de conscience. "
            "Ce système ne remplace pas une consultation médicale."
        )

    return (
        "Recommandation intermédiaire : repos, hydratation, surveillance de l’évolution des symptômes "
        "et consultation médicale si les symptômes persistent, s’aggravent ou si de nouveaux signes apparaissent. "
        "Ce système ne remplace pas une consultation médicale."
    )