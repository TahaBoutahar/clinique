# Medical Multi-Agent Clinical Orientation Assistant

## 1. Project Overview

This project is an academic multi-agent application that simulates a clinical orientation workflow.

The system allows a user to enter an initial patient case. Then, a Diagnostic Agent asks five patient questions. After collecting the answers, the system generates a preliminary clinical synthesis and an intermediate care recommendation. The workflow then pauses for a Human-in-the-Loop physician review. After the physician adds a treatment or conduct to follow, the Report Agent generates the final structured report.

This project uses:

- LangGraph
- LangChain-compatible architecture
- FastAPI
- MCP
- Streamlit
- LangGraph Studio
- uv for dependency management

> Important: This application is an academic simulation. It is not a medical device and does not provide a definitive diagnosis.

Required safety notice:

```text
Ce système ne remplace pas une consultation médicale.
```

---

## 2. Main Features

- Multi-agent workflow using LangGraph
- Supervisor node for orchestration
- Diagnostic Agent that asks exactly five patient questions
- Patient interaction through a tool
- Intermediate care recommendation
- MCP tool integration
- Human-in-the-Loop physician review
- Final structured report generation
- FastAPI backend
- Clean Streamlit frontend
- LangGraph Studio testing

---

## 3. Workflow

```text
START
  |
  v
Supervisor
  |
  v
Diagnostic Agent
  |
  +--> Tool: ask_patient
  |
  +--> MCP Tool: clinical_interim_care_tool
  |
  v
Supervisor
  |
  v
Physician Review
  |
  v
Supervisor
  |
  v
Report Agent
  |
  v
Supervisor
  |
  v
END
```

---

## 4. Project Architecture

```text
medical_multiagent/
├── backend/
│   └── app/
│       ├── __init__.py
│       ├── api.py
│       ├── graph.py
│       ├── state.py
│       ├── nodes/
│       │   ├── __init__.py
│       │   ├── supervisor.py
│       │   ├── diagnostic_agent.py
│       │   ├── physician_review.py
│       │   └── report_agent.py
│       └── tools/
│           ├── __init__.py
│           ├── patient_tools.py
│           ├── care_tools.py
│           └── mcp_client.py
│
├── mcp_server/
│   ├── server.py
│   └── data/
│
├── frontend/
│   ├── streamlit_app.py
│   └── .streamlit/
│       └── config.toml
│
├── langgraph.json
├── pyproject.toml
├── uv.lock
├── .env
├── .gitignore
└── README.md
```

---

## 5. Technologies Used

### Backend

- Python
- LangGraph
- LangChain
- FastAPI
- Pydantic
- Uvicorn

### MCP

- MCP Python SDK
- Local MCP server using stdio transport

### Frontend

- Streamlit
- Requests

### Development

- uv
- LangGraph Studio

---

## 6. Installation

### 6.1 Create the project

```bash
mkdir medical_multiagent
cd medical_multiagent
```

### 6.2 Initialize uv

```bash
uv init
```

### 6.3 Add backend dependencies

```bash
uv add langgraph langchain langchain-openai fastapi "uvicorn[standard]" pydantic python-dotenv
```

### 6.4 Add MCP dependency

```bash
uv add "mcp[cli]"
```

### 6.5 Add frontend dependencies

```bash
uv add streamlit requests
```

### 6.6 Add LangGraph CLI for Studio

```bash
uv add --dev "langgraph-cli[inmem]"
```

---

## 7. Environment Variables

Create a `.env` file in the project root:

```env
OPENAI_API_KEY=your_openai_api_key_here
LANGSMITH_TRACING=false
```

Do not push `.env` to GitHub.

For the current prototype, the main workflow can run with deterministic logic. The OpenAI key is kept for future LLM-based improvements.

---

## 8. LangGraph Configuration

The `langgraph.json` file allows LangGraph Studio to load the graph.

```json
{
  "dependencies": ["."],
  "graphs": {
    "medical_multiagent": "./backend/app/graph.py:graph"
  },
  "env": ".env"
}
```

---

## 9. Running the Backend API

Start the FastAPI backend:

```bash
uv run uvicorn backend.app.api:app --reload
```

The API will be available at:

```text
http://127.0.0.1:8000
```

FastAPI documentation:

```text
http://127.0.0.1:8000/docs
```

---

## 10. Running the Frontend

Open a second terminal and run:

```bash
uv run streamlit run frontend/streamlit_app.py
```

The frontend will open at:

```text
http://localhost:8501
```

---

## 11. Running LangGraph Studio

Start the LangGraph local development server:

```bash
uv run langgraph dev
```

Then open the Studio URL shown in the terminal.

Usually, the local server runs on:

```text
http://127.0.0.1:2024
```

LangGraph Studio allows visual testing of the graph and observation of transitions between nodes.

---

## 12. API Endpoints

### Root

```http
GET /
```

Returns a basic message confirming that the API is running.

---

### Start session

```http
POST /sessions/start
```

Request body:

```json
{
  "patient_initial_case": "fièvre et toux depuis deux jours"
}
```

Expected response:

```json
{
  "thread_id": "generated-session-id",
  "status": "awaiting_patient_answer",
  "state": {
    "current_question": "Depuis quand avez-vous ces symptômes ?"
  }
}
```

---

### Start consultation

```http
POST /consultation/start
```

This endpoint is an alias of `/sessions/start`.

Request body:

```json
{
  "patient_initial_case": "fièvre et toux depuis deux jours"
}
```

---

### Resume consultation

```http
POST /consultation/resume
```

This endpoint is used for both patient answers and physician review.

Patient answer example:

```json
{
  "thread_id": "your-thread-id",
  "patient_answer": "Depuis deux jours."
}
```

Physician review example:

```json
{
  "thread_id": "your-thread-id",
  "physician_treatment": "Traitement symptomatique, repos, hydratation et surveillance.",
  "physician_notes": "Cas à surveiller. Consultation recommandée si aggravation."
}
```

---

### Get consultation state

```http
GET /consultation/{thread_id}
```

Returns the current consultation state.

---

### Get final report

```http
GET /consultation/{thread_id}/report
```

Returns the final structured report after physician review.

---

## 13. Example Test with curl

### 13.1 Start a session

```bash
curl -X POST "http://127.0.0.1:8000/sessions/start" \
-H "Content-Type: application/json" \
-d '{"patient_initial_case": "fièvre et toux depuis deux jours"}'
```

Copy the returned `thread_id`.

---

### 13.2 Answer the five patient questions

Replace `YOUR_THREAD_ID` with the real session ID.

```bash
curl -X POST "http://127.0.0.1:8000/consultation/resume" \
-H "Content-Type: application/json" \
-d '{"thread_id": "YOUR_THREAD_ID", "patient_answer": "Depuis deux jours."}'

curl -X POST "http://127.0.0.1:8000/consultation/resume" \
-H "Content-Type: application/json" \
-d '{"thread_id": "YOUR_THREAD_ID", "patient_answer": "J’ai une fièvre légère et une fatigue."}'

curl -X POST "http://127.0.0.1:8000/consultation/resume" \
-H "Content-Type: application/json" \
-d '{"thread_id": "YOUR_THREAD_ID", "patient_answer": "Je n’ai pas d’antécédents médicaux importants."}'

curl -X POST "http://127.0.0.1:8000/consultation/resume" \
-H "Content-Type: application/json" \
-d '{"thread_id": "YOUR_THREAD_ID", "patient_answer": "Les symptômes sont stables."}'

curl -X POST "http://127.0.0.1:8000/consultation/resume" \
-H "Content-Type: application/json" \
-d '{"thread_id": "YOUR_THREAD_ID", "patient_answer": "Pas de difficulté à respirer ni de douleur intense."}'
```

After the fifth answer, the system should return:

```text
awaiting_physician_review
```

---

### 13.3 Submit physician review

```bash
curl -X POST "http://127.0.0.1:8000/consultation/resume" \
-H "Content-Type: application/json" \
-d '{
  "thread_id": "YOUR_THREAD_ID",
  "physician_treatment": "Traitement symptomatique, repos, hydratation et surveillance. Consultation médicale si aggravation.",
  "physician_notes": "Cas compatible avec une orientation clinique bénigne sous réserve d’un examen médical réel."
}'
```

The system should return:

```text
completed
```

---

### 13.4 Get final report

```bash
curl -X GET "http://127.0.0.1:8000/consultation/YOUR_THREAD_ID/report"
```

---

## 14. LangGraph Studio Test Inputs

### 14.1 Initial patient case test

```json
{
  "messages": [],
  "next": "diagnostic_agent",
  "question_count": 0,
  "patient_initial_case": "fièvre et toux",
  "patient_answers": [],
  "questions_asked": [],
  "interim_care": "",
  "diagnostic_summary": "",
  "physician_treatment": "",
  "physician_notes": "",
  "final_report": "",
  "red_flags_detected": false,
  "session_status": "started"
}
```

Expected output:

```text
session_status: awaiting_patient_answer
current_question: Depuis quand avez-vous ces symptômes ?
```

---

### 14.2 Five answers test

```json
{
  "messages": [],
  "next": "diagnostic_agent",
  "question_count": 5,
  "patient_initial_case": "fièvre et toux",
  "patient_answers": [
    "Depuis deux jours.",
    "J’ai une fièvre légère et une fatigue.",
    "Je n’ai pas d’antécédents importants.",
    "Les symptômes sont stables.",
    "Pas de difficulté à respirer ni douleur intense."
  ],
  "questions_asked": [
    "Depuis quand avez-vous ces symptômes ?",
    "Avez-vous de la fièvre, des douleurs, une fatigue importante ou d’autres signes associés ?",
    "Avez-vous des antécédents médicaux importants ou prenez-vous un traitement actuellement ?",
    "Les symptômes s’aggravent-ils, s’améliorent-ils ou restent-ils stables ?",
    "Avez-vous des signes inquiétants comme une difficulté à respirer, une douleur intense, une confusion ou une aggravation rapide ?"
  ],
  "interim_care": "",
  "diagnostic_summary": "",
  "physician_treatment": "",
  "physician_notes": "",
  "final_report": "",
  "red_flags_detected": false,
  "session_status": "patient_answer_received"
}
```

Expected output:

```text
session_status: awaiting_physician_review
```

---

### 14.3 Final report test

```json
{
  "messages": [],
  "next": "report_agent",
  "question_count": 5,
  "patient_initial_case": "fièvre et toux",
  "patient_answers": [
    "Depuis deux jours.",
    "J’ai une fièvre légère et une fatigue.",
    "Je n’ai pas d’antécédents importants.",
    "Les symptômes sont stables.",
    "Pas de difficulté à respirer ni douleur intense."
  ],
  "questions_asked": [
    "Depuis quand avez-vous ces symptômes ?",
    "Avez-vous de la fièvre, des douleurs, une fatigue importante ou d’autres signes associés ?",
    "Avez-vous des antécédents médicaux importants ou prenez-vous un traitement actuellement ?",
    "Les symptômes s’aggravent-ils, s’améliorent-ils ou restent-ils stables ?",
    "Avez-vous des signes inquiétants comme une difficulté à respirer, une douleur intense, une confusion ou une aggravation rapide ?"
  ],
  "diagnostic_summary": "Synthèse clinique préliminaire : syndrome respiratoire simple probable, sans diagnostic définitif.",
  "interim_care": "Repos, hydratation, surveillance et consultation si aggravation. Ce système ne remplace pas une consultation médicale.",
  "physician_treatment": "Traitement symptomatique, repos, hydratation et surveillance.",
  "physician_notes": "Cas à surveiller, consultation si aggravation.",
  "final_report": "",
  "red_flags_detected": false,
  "session_status": "physician_review_submitted"
}
```

Expected output:

```text
session_status: completed
final_report: RAPPORT FINAL STRUCTURÉ
```

---

## 15. Test Scenarios

### Case 1: Simple respiratory syndrome

Initial case:

```text
fièvre et toux depuis deux jours
```

Expected behavior:

- Five patient questions are asked.
- A preliminary synthesis is generated.
- The intermediate recommendation suggests rest, hydration and monitoring.
- Physician review is required.
- The final report is generated.

---

### Case 2: Case with red flags

Initial case:

```text
douleur thoracique avec difficulté à respirer
```

Expected behavior:

- Five patient questions are asked.
- Red flags may be detected.
- The intermediate recommendation suggests urgent medical consultation.
- Physician review is required.
- The final report is generated.

---

### Case 3: Benign case

Initial case:

```text
fatigue légère sans fièvre
```

Expected behavior:

- Five patient questions are asked.
- No red flags are detected.
- The intermediate recommendation remains cautious.
- Physician review is required.
- The final report is generated.

---

## 16. MCP Integration

The project includes a local MCP server:

```text
mcp_server/server.py
```

The MCP server exposes this tool:

```text
clinical_interim_care_tool
```

This tool receives:

- Patient initial case
- Patient answers

It returns:

- Red flag detection result
- Intermediate care recommendation
- Safety notice

The Diagnostic Agent calls this MCP tool through:

```text
backend/app/tools/mcp_client.py
```

If the MCP server fails, the backend uses a safe local fallback recommendation.

---

## 17. Human-in-the-Loop

The Human-in-the-Loop step is represented by the Physician Review node.

The workflow stops after the preliminary synthesis and intermediate recommendation are generated.

The physician must manually provide:

- Treatment or conduct to follow
- Optional notes

Only after this review does the Report Agent generate the final structured report.

---

## 18. Frontend Screens

The Streamlit frontend includes four main screens:

### Screen 1: Initial Case Input

The user enters the initial patient case.

### Screen 2: Patient Q&A

The system asks five patient questions one by one.

### Screen 3: Physician Review

The doctor reviews the preliminary synthesis and adds treatment or conduct to follow.

### Screen 4: Final Report

The system displays the final structured report and allows the user to download it as a text file.

---

## 19. Safety and Ethical Limits

This project is only an academic simulation.

The system:

- Does not provide a definitive diagnosis
- Does not replace a physician
- Does not make autonomous medical decisions
- Uses cautious wording
- Requires physician validation before final report generation

Required safety sentence:

```text
Ce système ne remplace pas une consultation médicale.
```

---

## 20. Troubleshooting

### FastAPI server is not running

Start the backend:

```bash
uv run uvicorn backend.app.api:app --reload
```

---

### Streamlit cannot connect to backend

Make sure FastAPI is running at:

```text
http://127.0.0.1:8000
```

Then restart Streamlit:

```bash
uv run streamlit run frontend/streamlit_app.py
```

---

### LangGraph Studio does not start

Try:

```bash
uv sync --dev
uv run langgraph dev
```

---

### MCP tool fails

Test MCP manually:

```bash
uv run python -c "from backend.app.tools.mcp_client import call_mcp_interim_care_sync; print(call_mcp_interim_care_sync('fièvre et toux', ['Depuis deux jours', 'Fièvre légère', 'Pas d’antécédents', 'Stable', 'Pas de difficulté à respirer']))"
```

If MCP fails, the backend still uses a local fallback recommendation.

---

## 21. Future Improvements

Possible bonus improvements:

- Database persistence with SQLite or PostgreSQL
- PDF export for the final report
- Authentication for physician review
- Better red flag detection
- Structured JSON output with Pydantic
- Unit tests and integration tests
- Docker and docker-compose
- Consultation history
- LLM-based synthesis generation
- Role-based access for patient and physician

---

## 22. Evaluation Criteria Coverage

| Requirement | Status |
|---|---|
| LangGraph workflow | Implemented |
| Supervisor | Implemented |
| Diagnostic Agent | Implemented |
| Report Agent | Implemented |
| Physician Human-in-the-Loop | Implemented |
| Five patient questions | Implemented |
| Tool usage | Implemented |
| MCP integration | Implemented |
| FastAPI API | Implemented |
| Frontend | Implemented with Streamlit |
| LangGraph Studio testing | Supported |
| Final structured report | Implemented |
| Safety notice | Included |

---

## 23. Disclaimer

This project is for educational purposes only.

It is not a certified medical tool and must not be used as a substitute for a real medical consultation.

Final required notice:

```text
Ce système ne remplace pas une consultation médicale.
```