def main():
    print("Hello from clinic-multi!")


if __name__ == "__main__":
    main()
