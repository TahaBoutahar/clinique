import json
from typing import List

from mcp.server.fastmcp import FastMCP


mcp = FastMCP("Medical Clinical Orientation MCP")


def detect_red_flags_from_text(text: str) -> bool:
    red_flag_keywords = [
        "difficulté à respirer",
        "difficulte a respirer",
        "respirer",
        "essoufflement",
        "douleur intense",
        "confusion",
        "perte de connaissance",
        "sang",
        "aggravation rapide",
        "urgence",
        "malaise",
    ]

    text = text.lower()
    return any(keyword in text for keyword in red_flag_keywords)


@mcp.tool()
def clinical_interim_care_tool(
    patient_initial_case: str,
    patient_answers: List[str],
) -> str:
    """
    MCP tool that generates cautious intermediate care guidance.
    This is for academic clinical-orientation simulation only.
    It does not provide a definitive medical diagnosis.
    """

    combined_text = patient_initial_case + " " + " ".join(patient_answers)
    red_flags_detected = detect_red_flags_from_text(combined_text)

    if red_flags_detected:
        interim_care = (
            "Recommandation intermédiaire : présence possible de signes d’alerte. "
            "Une consultation médicale rapide ou une orientation vers un service d’urgence "
            "est recommandée en cas d’aggravation, de difficulté respiratoire, de douleur intense "
            "ou de trouble de conscience."
        )
    else:
        interim_care = (
            "Recommandation intermédiaire : repos, hydratation, surveillance de l’évolution "
            "des symptômes et consultation médicale si les symptômes persistent, s’aggravent "
            "ou si de nouveaux signes apparaissent."
        )

    result = {
        "source": "MCP clinical_interim_care_tool",
        "red_flags_detected": red_flags_detected,
        "interim_care": interim_care,
        "safety_notice": "Ce système ne remplace pas une consultation médicale.",
    }

    return json.dumps(result, ensure_ascii=False)


if __name__ == "__main__":
    mcp.run(transport="stdio")