import requests
import streamlit as st


API_BASE_URL = "http://127.0.0.1:8000"


st.set_page_config(
    page_title="Clinical Orientation Assistant",
    page_icon="🩺",
    layout="wide",
)


# -----------------------------
# Custom CSS: white + red theme
# -----------------------------
st.markdown(
    """
    <style>
    .main {
        background-color: #FFFFFF;
    }

    .block-container {
        padding-top: 2rem;
        padding-bottom: 2rem;
        max-width: 1200px;
    }

    .hero {
        padding: 32px;
        border-radius: 22px;
        background: linear-gradient(135deg, #FFFFFF 0%, #FFF1F1 100%);
        border: 1px solid #FECACA;
        box-shadow: 0 12px 35px rgba(185, 28, 28, 0.10);
        margin-bottom: 26px;
    }

    .hero-title {
        font-size: 42px;
        font-weight: 800;
        color: #991B1B;
        margin-bottom: 8px;
        letter-spacing: -1px;
    }

    .hero-subtitle {
        font-size: 17px;
        color: #4B5563;
        line-height: 1.6;
        max-width: 900px;
    }

    .warning-box {
        padding: 16px 18px;
        border-radius: 16px;
        background-color: #FEF2F2;
        border-left: 6px solid #DC2626;
        color: #7F1D1D;
        font-weight: 600;
        margin-bottom: 24px;
    }

    .card {
        padding: 24px;
        border-radius: 20px;
        background-color: #FFFFFF;
        border: 1px solid #FECACA;
        box-shadow: 0 8px 22px rgba(0, 0, 0, 0.05);
        margin-bottom: 18px;
    }

    .step-badge {
        display: inline-block;
        padding: 7px 14px;
        border-radius: 999px;
        background-color: #B91C1C;
        color: white;
        font-size: 13px;
        font-weight: 700;
        margin-bottom: 14px;
    }

    .section-title {
        color: #991B1B;
        font-size: 26px;
        font-weight: 800;
        margin-bottom: 10px;
    }

    .small-muted {
        color: #6B7280;
        font-size: 14px;
    }

    .status-pill {
        display: inline-block;
        padding: 8px 14px;
        border-radius: 999px;
        background-color: #FEF2F2;
        color: #991B1B;
        border: 1px solid #FCA5A5;
        font-weight: 700;
        font-size: 13px;
    }

    div.stButton > button {
        background-color: #B91C1C;
        color: white;
        border-radius: 14px;
        border: none;
        padding: 0.65rem 1rem;
        font-weight: 700;
        transition: 0.2s ease;
    }

    div.stButton > button:hover {
        background-color: #991B1B;
        color: white;
        border: none;
        transform: translateY(-1px);
    }

    textarea, input {
        border-radius: 14px !important;
    }

    .report-box {
        background-color: #FFFFFF;
        border: 1px solid #FECACA;
        border-radius: 18px;
        padding: 22px;
        white-space: pre-wrap;
        line-height: 1.65;
        color: #111827;
    }

    .footer {
        margin-top: 32px;
        color: #9CA3AF;
        font-size: 13px;
        text-align: center;
    }
    </style>
    """,
    unsafe_allow_html=True,
)


# -----------------------------
# Session state
# -----------------------------
def init_state():
    defaults = {
        "thread_id": None,
        "api_state": None,
        "current_step": "start",
        "patient_case": "",
        "answer_input": "",
        "physician_treatment": "",
        "physician_notes": "",
    }

    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


init_state()


# -----------------------------
# API helpers
# -----------------------------
def start_session(patient_initial_case: str):
    response = requests.post(
        f"{API_BASE_URL}/sessions/start",
        json={"patient_initial_case": patient_initial_case},
        timeout=30,
    )
    response.raise_for_status()
    return response.json()


def resume_with_patient_answer(thread_id: str, patient_answer: str):
    response = requests.post(
        f"{API_BASE_URL}/consultation/resume",
        json={
            "thread_id": thread_id,
            "patient_answer": patient_answer,
        },
        timeout=30,
    )
    response.raise_for_status()
    return response.json()


def resume_with_physician_review(
    thread_id: str,
    physician_treatment: str,
    physician_notes: str,
):
    response = requests.post(
        f"{API_BASE_URL}/consultation/resume",
        json={
            "thread_id": thread_id,
            "physician_treatment": physician_treatment,
            "physician_notes": physician_notes,
        },
        timeout=30,
    )
    response.raise_for_status()
    return response.json()


def get_report(thread_id: str):
    response = requests.get(
        f"{API_BASE_URL}/consultation/{thread_id}/report",
        timeout=30,
    )
    response.raise_for_status()
    return response.json()


def update_current_step_from_status(status: str):
    if status == "awaiting_patient_answer":
        st.session_state.current_step = "questions"
    elif status == "awaiting_physician_review":
        st.session_state.current_step = "physician"
    elif status == "completed":
        st.session_state.current_step = "report"


def reset_app():
    st.session_state.thread_id = None
    st.session_state.api_state = None
    st.session_state.current_step = "start"
    st.session_state.patient_case = ""
    st.session_state.answer_input = ""
    st.session_state.physician_treatment = ""
    st.session_state.physician_notes = ""


# -----------------------------
# Header
# -----------------------------
st.markdown(
    """
    <div class="hero">
        <div class="hero-title">Clinical Orientation Assistant</div>
        <div class="hero-subtitle">
            Academic multi-agent simulation using LangGraph, FastAPI, MCP and Human-in-the-Loop physician review.
            The system collects patient information, creates a preliminary clinical synthesis, then waits for doctor validation before generating the final report.
        </div>
    </div>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    """
    <div class="warning-box">
        ⚠️ Ce système ne remplace pas une consultation médicale. Il ne fournit pas de diagnostic définitif.
    </div>
    """,
    unsafe_allow_html=True,
)


# -----------------------------
# Sidebar
# -----------------------------
with st.sidebar:
    st.markdown("## 🩺 Workflow")
    st.markdown("**1.** Initial patient case")
    st.markdown("**2.** Five patient questions")
    st.markdown("**3.** Preliminary clinical synthesis")
    st.markdown("**4.** Physician review")
    st.markdown("**5.** Final structured report")

    st.divider()

    if st.session_state.thread_id:
        st.markdown("### Session")
        st.code(st.session_state.thread_id)

    if st.session_state.api_state:
        status = st.session_state.api_state.get("status", "unknown")
        st.markdown(f'<span class="status-pill">{status}</span>', unsafe_allow_html=True)

    st.divider()

    if st.button("Reset consultation"):
        reset_app()
        st.rerun()


# -----------------------------
# Step 1: Start consultation
# -----------------------------
if st.session_state.current_step == "start":
    col1, col2 = st.columns([1.2, 0.8])

    with col1:
        st.markdown('<div class="card">', unsafe_allow_html=True)
        st.markdown('<span class="step-badge">STEP 1</span>', unsafe_allow_html=True)
        st.markdown('<div class="section-title">Start consultation</div>', unsafe_allow_html=True)

        patient_case = st.text_area(
            "Initial patient case",
            placeholder="Example: fièvre et toux depuis deux jours...",
            height=160,
            value=st.session_state.patient_case,
        )

        if st.button("Start clinical orientation"):
            if not patient_case.strip():
                st.error("Please enter the initial patient case.")
            else:
                try:
                    result = start_session(patient_case.strip())

                    st.session_state.thread_id = result["thread_id"]
                    st.session_state.api_state = result
                    st.session_state.patient_case = patient_case.strip()

                    update_current_step_from_status(result["status"])
                    st.rerun()

                except requests.exceptions.ConnectionError:
                    st.error("FastAPI server is not running. Start it with: uv run uvicorn backend.app.api:app --reload")
                except Exception as error:
                    st.error(f"Error: {error}")

        st.markdown("</div>", unsafe_allow_html=True)

    with col2:
        st.markdown(
            """
            <div class="card">
                <span class="step-badge">INFO</span>
                <div class="section-title">Project rules</div>
                <p class="small-muted">
                    This app is an academic simulation. It uses cautious wording:
                    orientation clinique préliminaire, synthèse clinique, and recommandation intermédiaire.
                </p>
            </div>
            """,
            unsafe_allow_html=True,
        )


# -----------------------------
# Step 2: Patient questions
# -----------------------------
elif st.session_state.current_step == "questions":
    state = st.session_state.api_state["state"]

    current_question = state.get("current_question", "")
    question_count = state.get("question_count", 0)
    questions_asked = state.get("questions_asked", [])
    patient_answers = state.get("patient_answers", [])

    col1, col2 = st.columns([1.2, 0.8])

    with col1:
        st.markdown('<div class="card">', unsafe_allow_html=True)
        st.markdown('<span class="step-badge">STEP 2</span>', unsafe_allow_html=True)
        st.markdown('<div class="section-title">Patient Q&A</div>', unsafe_allow_html=True)

        st.progress(min(question_count / 5, 1.0))
        st.markdown(f"**Question {question_count + 1}/5**")

        st.info(current_question)

        answer = st.text_area(
            "Patient answer",
            placeholder="Write the patient answer here...",
            height=130,
            key="answer_area",
        )

        if st.button("Submit answer"):
            if not answer.strip():
                st.error("Please enter the patient answer.")
            else:
                try:
                    result = resume_with_patient_answer(
                        st.session_state.thread_id,
                        answer.strip(),
                    )

                    st.session_state.api_state = result
                    update_current_step_from_status(result["status"])

                    st.rerun()

                except Exception as error:
                    st.error(f"Error: {error}")

        st.markdown("</div>", unsafe_allow_html=True)

    with col2:
        st.markdown('<div class="card">', unsafe_allow_html=True)
        st.markdown('<span class="step-badge">ANSWERS</span>', unsafe_allow_html=True)
        st.markdown('<div class="section-title">Collected answers</div>', unsafe_allow_html=True)

        if not patient_answers:
            st.markdown('<p class="small-muted">No answers yet.</p>', unsafe_allow_html=True)
        else:
            for index, answer_item in enumerate(patient_answers):
                question_text = questions_asked[index] if index < len(questions_asked) else "Question"
                st.markdown(f"**Q{index + 1}. {question_text}**")
                st.markdown(f"{answer_item}")
                st.divider()

        st.markdown("</div>", unsafe_allow_html=True)


# -----------------------------
# Step 3: Physician review
# -----------------------------
elif st.session_state.current_step == "physician":
    state = st.session_state.api_state["state"]

    diagnostic_summary = state.get("diagnostic_summary", "")
    interim_care = state.get("interim_care", "")
    red_flags = state.get("red_flags_detected", False)

    col1, col2 = st.columns([1, 1])

    with col1:
        st.markdown('<div class="card">', unsafe_allow_html=True)
        st.markdown('<span class="step-badge">STEP 3</span>', unsafe_allow_html=True)
        st.markdown('<div class="section-title">Physician review</div>', unsafe_allow_html=True)

        physician_treatment = st.text_area(
            "Treatment or conduct to follow",
            placeholder="Example: Traitement symptomatique, repos, hydratation, surveillance...",
            height=150,
        )

        physician_notes = st.text_area(
            "Physician notes",
            placeholder="Optional notes...",
            height=120,
        )

        if st.button("Validate and generate report"):
            if not physician_treatment.strip():
                st.error("Please enter the physician treatment or conduct.")
            else:
                try:
                    result = resume_with_physician_review(
                        st.session_state.thread_id,
                        physician_treatment.strip(),
                        physician_notes.strip(),
                    )

                    st.session_state.api_state = result
                    update_current_step_from_status(result["status"])
                    st.rerun()

                except Exception as error:
                    st.error(f"Error: {error}")

        st.markdown("</div>", unsafe_allow_html=True)

    with col2:
        st.markdown('<div class="card">', unsafe_allow_html=True)
        st.markdown('<span class="step-badge">SYNTHESIS</span>', unsafe_allow_html=True)
        st.markdown('<div class="section-title">Preliminary synthesis</div>', unsafe_allow_html=True)

        if red_flags:
            st.error("Possible red flags detected.")
        else:
            st.success("No red flags detected in this prototype.")

        st.markdown("### Synthèse clinique préliminaire")
        st.text_area(
            "Diagnostic summary",
            value=diagnostic_summary,
            height=250,
            disabled=True,
            label_visibility="collapsed",
        )

        st.markdown("### Recommandation intermédiaire")
        st.text_area(
            "Interim care",
            value=interim_care,
            height=150,
            disabled=True,
            label_visibility="collapsed",
        )

        st.markdown("</div>", unsafe_allow_html=True)


# -----------------------------
# Step 4: Final report
# -----------------------------
elif st.session_state.current_step == "report":
    state = st.session_state.api_state["state"]
    final_report = state.get("final_report", "")

    st.markdown('<div class="card">', unsafe_allow_html=True)
    st.markdown('<span class="step-badge">STEP 4</span>', unsafe_allow_html=True)
    st.markdown('<div class="section-title">Final structured report</div>', unsafe_allow_html=True)

    if not final_report:
        try:
            report_result = get_report(st.session_state.thread_id)
            final_report = report_result.get("final_report", "")
        except Exception:
            pass

    st.markdown(f'<div class="report-box">{final_report}</div>', unsafe_allow_html=True)

    st.download_button(
        label="Download report as TXT",
        data=final_report,
        file_name="clinical_orientation_report.txt",
        mime="text/plain",
    )

    st.markdown("</div>", unsafe_allow_html=True)


st.markdown(
    """
    <div class="footer">
        Academic project — LangGraph · FastAPI · MCP · Streamlit
    </div>
    """,
    unsafe_allow_html=True,
)